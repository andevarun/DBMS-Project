package Sat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class Students
{
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbluser_id,lblname,lblrollno,lbldiv,lbldept_id;
	private JTextField txtuser_id,txtname,txtrollno,txtdiv,txtdept_id;
	private List RollnoList;
	Connection con;
	ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Students(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{	
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lbluser_id=new JLabel("User_id");
		lblname=new JLabel("Name");
		lblrollno=new JLabel("Roll Number");
		lbldiv=new JLabel("Division");
		lbldept_id=new JLabel("Dept_id");
		txtuser_id=new JTextField(50);
		txtname=new JTextField(50);
		txtrollno=new JTextField(10);
		txtdiv=new JTextField(10);
		txtdept_id=new JTextField(10);
		this.p=p;	
	}
	public void connectToDB() 
    {
		try {
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737121","vasavi");  
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadrollno() {
		try {
			RollnoList.removeAll();
			rs=statement.executeQuery("select rollnumber from students");
			while(rs.next()) {
				RollnoList.add(rs.getString("rollnumber"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() 
	{
		//if(loginpage.s=="staff" || loginpage.s=="admin")
		//{
		insertButton=new JButton("Submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				txtuser_id.setText(null);
				txtname.setText(null); 
				txtrollno.setText(null); 
				txtdiv.setText(null); 
				txtdept_id.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				 p1.setLayout(new GridLayout(3,2));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblname);
				 p1.add(txtname);
				 p1.add(lblrollno);
				 p1.add(txtrollno);
				 p1.add(lbldiv);
				 p1.add(txtdiv);
				 p1.add(lbldept_id);
				 p1.add(txtdept_id);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 RollnoList=new List(10);
					 loadrollno();
					 p2.add(RollnoList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				   insertButton.addActionListener(new ActionListener() {
					 
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO STUDENTS VALUES('"+txtname.getText()+"',"+txtrollno.getText()+",'"+txtdiv.getText()+"',"+txtdept_id.getText()+",'"+txtuser_id.getText()+"')";
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nInserted "+i+" rows succesfully"); 
					loadrollno();
					System.out.println("Done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
	
			});
		

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtuser_id.setText(null);
				txtname.setText(null); 
				txtrollno.setText(null); 
				txtdiv.setText(null); 
				txtdept_id.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();				
				p1=new JPanel();
				 p1.setLayout(new GridLayout(3,2));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblname);
				 p1.add(txtname);
				 p1.add(lblrollno);
				 p1.add(txtrollno);
				 p1.add(lbldiv);
				 p1.add(txtdiv);
				 p1.add(lbldept_id);
				 p1.add(txtdept_id);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					 RollnoList=new List(10);
					 loadrollno();
					 p2.add(RollnoList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				   RollnoList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from students");
								while (rs.next()) 
								{
									if (rs.getString("ROLLNUMBER").equals(RollnoList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtuser_id.setText(rs.getString("user_id"));
									txtname.setText(rs.getString("name")); 
									txtrollno.setText(rs.getString("rollnumber")); 
									txtdiv.setText(rs.getString("division")); 
									txtdept_id.setText(rs.getString("dept_id")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM STUDENTS WHERE ROLLNUMBER="+RollnoList.getSelectedItem();
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadrollno();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				
				txtname.setText(null); 
				txtrollno.setText(null); 
				txtdiv.setText(null); 
				txtdept_id.setText(null); 
				txtuser_id.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,2));
			
				 p1.add(lblname);
				 p1.add(txtname);
				 p1.add(lblrollno);
				 p1.add(txtrollno);
				 p1.add(lbldiv);
				 p1.add(txtdiv);
				 p1.add(lbldept_id);
				 p1.add(txtdept_id);
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 RollnoList=new List(10);
					 loadrollno();
					 p2.add(RollnoList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 RollnoList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from students");
								while (rs.next()) 
								{
									if (rs.getString("Rollnumber").equals(RollnoList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtuser_id.setText(rs.getString("user_id"));
									txtname.setText(rs.getString("name")); 
									txtrollno.setText(rs.getString("rollnumber")); 
									txtdiv.setText(rs.getString("division")); 
									txtdept_id.setText(rs.getString("dept_id")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					loadrollno();
					 String query="update students set name='"+txtname.getText()+"',division='"+txtdiv.getText()+"',dept_id="+txtdept_id.getText()+" WHERE rollnumber="+txtrollno.getText()+" ";
					 int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadrollno();
					
					
				}
				catch(SQLException updateException){
					
					displaySQLErrors(updateException);
				}
				
				 }
			
			
				 	});
			}
			});
		//}
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Students view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.blue) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Students details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						      
						       
						       model.addColumn("name");
						       model.addColumn("rollnumber");
						       model.addColumn("division");
						       model.addColumn("dept_id");
						       model.addColumn("user_id");
						      
						       try {
									
									rs=statement.executeQuery("select * from students");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("name"),rs.getString("rollnumber"),rs.getString("division"),rs.getString("dept_id"),rs.getString("user_id")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
}
