package Sat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class Views {
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblrno,lbldue,lbldiv,lblaname;
	private JTextField txtrno,txtdue,txtdiv,txtaname;
	private List rnoList;
	Connection con;
	ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Views(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{	
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lblrno=new JLabel("Roll Number");
		lbldue=new JLabel("Due Date");
		lbldiv=new JLabel("Division");
		lblaname=new JLabel("Assignment Name");
		txtrno=new JTextField(5);
		txtdue=new JTextField(12);
		txtdiv=new JTextField(3);
		txtaname=new JTextField(20);
		this.p=p;	
	}
	public void connectToDB() 
    {
		try {
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737121","vasavi");  
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadrno() 
	
	{
		try 
		{
			rnoList.removeAll();
			rs=statement.executeQuery("select rollnumber from views");
			while(rs.next()) 
			{
				rnoList.add(rs.getString("rollnumber"));
			}
		}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		insertButton=new JButton("Submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				txtrno.setText(null); 
				txtdue.setText(null); 
				txtdiv.setText(null);  
				txtaname.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblrno);
				 p1.add(txtrno);
				 p1.add(lbldue);
				 p1.add(txtdue);
				 p1.add(lbldiv);
				 p1.add(txtdiv);
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 rnoList=new List(10);
					 loadrno();
					 p2.add(rnoList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				   insertButton.addActionListener(new ActionListener() {
					 
					 @Override
						public void actionPerformed(ActionEvent e) {	 
				try {
					String query="INSERT INTO VIEWS VALUES("+txtrno.getText()+",'"+txtdue.getText()+"','"+txtdiv.getText()+"','"+txtaname.getText()+"')";
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nInserted "+i+" rows succesfully"); 
					loadrno();
					System.out.println("Done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				
				txtrno.setText(null); 
				txtdue.setText(null); 
				txtdiv.setText(null);
				txtaname.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();				
				p1=new JPanel();
				 p1.setLayout(new GridLayout(4,2));
			
				 p1.add(lblrno);
				 p1.add(txtrno);
				 p1.add(lbldue);
				 p1.add(txtdue);
				 p1.add(lbldiv);
				 p1.add(txtdiv);
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					 rnoList=new List(10);
					 loadrno();
					 p2.add(rnoList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				  rnoList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from views");
								while (rs.next()) 
								{
									if (rs.getString("rollnumber").equals(rnoList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtrno.setText(rs.getString("rollnumber"));
									
									txtdue.setText(rs.getString("due_date")); 
									txtdiv.setText(rs.getString("division")); 
									txtaname.setText(rs.getString("assign_name")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					// aname=JOptionPane.showInputDialog(p,"Enter the assignment name");
					
					//txtaname.setText(aname);
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM VIEWS WHERE rollnumber="+rnoList.getSelectedItem();
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadrno();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				txtrno.setText(null); 
				txtdue.setText(null); 
				txtdiv.setText(null); 
				txtaname.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblrno);
				 p1.add(txtrno);
				 p1.add(lbldue);
				 p1.add(txtdue);
				 p1.add(lbldiv);
				 p1.add(txtdiv);
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 rnoList=new List(10);
					 loadrno();
					 p2.add(rnoList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 rnoList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from views");
								while (rs.next()) 
								{
									if (rs.getString("rollnumber").equals(rnoList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtrno.setText(rs.getString("rollnumber"));
									
									txtdue.setText(rs.getString("due_date")); 
									txtdiv.setText(rs.getString("division")); 
									txtaname.setText(rs.getString("assign_name")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					loadrno();
					
					 String query="update views set due_date='"+txtdue.getText()+"',division='"+txtdiv.getText()+"',assign_name='"+txtaname.getText()+"' where rollnumber="+txtrno.getText()+" ";
					
					 int i=statement.executeUpdate(query);
					
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadrno();
					
					
				}
				catch(SQLException updateException){
					
					displaySQLErrors(updateException);
				}
				
				 }
			
			
				 	});
			}
			});
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Student assignments view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);
				p1.setBackground(Color.cyan) ;
				p2.setBackground(Color.blue) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Student Assignments details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("rollnumber");
						       
						     
						       model.addColumn("due_date");
						      
						       model.addColumn("division");
						       model.addColumn("assign_name");
						      
						       try {
									
									rs=statement.executeQuery("select * from views");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("rollnumber"),rs.getString("due_date"),rs.getString("division"),rs.getString("assign_name")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
}
