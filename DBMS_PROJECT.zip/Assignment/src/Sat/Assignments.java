package Sat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class Assignments {
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblaname,lblpts,lblfeedback,lblrno;
	private JTextField txtaname,txtpts,txtfeedback,txtrno;
	private List anameList;
	Connection con;
	ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Assignments(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{	
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lblrno=new JLabel("Roll Number");
		lblaname=new JLabel("Assignment Name");
		lblpts=new JLabel("Points");
		lblfeedback=new JLabel("Feedback");
		txtrno=new JTextField(10);
		txtaname=new JTextField(50);
		txtpts=new JTextField(50);
		txtfeedback=new JTextField(50);
		txtrno=new JTextField(10);
		this.p=p;	
	}
	public void connectToDB() 
    {
		try {
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737121","vasavi");  
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadaname() {
		try {
			anameList.removeAll();
			rs=statement.executeQuery("select assign_name from assignments");
			while(rs.next()) {
				anameList.add(rs.getString("assign_name"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		insertButton=new JButton("Submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				txtaname.setText(null);
				txtpts.setText(null); 
				txtfeedback.setText(null); 
				txtrno.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				 p1.setLayout(new GridLayout(4,1));
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p1.add(lblpts);
				 p1.add(txtpts);
				 p1.add(lblfeedback);
				 p1.add(txtfeedback);
				 p1.add(lblrno);
				 p1.add(txtrno);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 anameList=new List(10);
					 loadaname();
					 p2.add(anameList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				   insertButton.addActionListener(new ActionListener() {
					 
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO ASSIGNMENTS VALUES('"+txtaname.getText()+"',"+txtpts.getText()+",'"+txtfeedback.getText()+"',"+txtrno.getText()+")";
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nInserted "+i+" rows succesfully"); 
					loadaname();
					System.out.println("Done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtaname.setText(null);
				txtpts.setText(null); 
				txtfeedback.setText(null); 
				txtrno.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();				
				p1=new JPanel();
				 p1.setLayout(new GridLayout(4,1));
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p1.add(lblpts);
				 p1.add(txtpts);
				 p1.add(lblfeedback);
				 p1.add(txtfeedback);
				 p1.add(lblrno);
				 p1.add(txtrno);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					 anameList=new List(10);
					 loadaname();
					 p2.add(anameList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				  anameList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from assignments");
								while (rs.next()) 
								{
									if (rs.getString("assign_name").equals(anameList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtaname.setText(rs.getString("assign_name"));
									txtpts.setText(rs.getString("points"));  
									txtfeedback.setText(rs.getString("feedback")); 
									txtrno.setText(rs.getString("rollnumber")); 
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					String aname=JOptionPane.showInputDialog(p,"Enter the assignment name");
					
					txtaname.setText(aname);
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM ASSIGNMENTS WHERE assign_name='"+txtaname.getText()+"' ";
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadaname();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				txtaname.setText(null);
				txtpts.setText(null); 
				txtfeedback.setText(null); 
				txtrno.setText(null);  
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,1));
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p1.add(lblpts);
				 p1.add(txtpts);
				 p1.add(lblfeedback);
				 p1.add(txtfeedback);
				 p1.add(lblrno);
				 p1.add(txtrno);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 anameList=new List(10);
					 loadaname();
					 p2.add(anameList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 anameList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from assignments");
								while (rs.next()) 
								{
									if (rs.getString("assign_name").equals(anameList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtaname.setText(rs.getString("assign_name"));
									txtpts.setText(rs.getString("points"));  
									txtfeedback.setText(rs.getString("feedback")); 
									txtrno.setText(rs.getString("rollnumber")); 
									
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				 p.setLayout(new BorderLayout());
					
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					loadaname();  
					 String query="update assignments set points="+txtpts.getText()+",feedback='"+txtfeedback.getText()+"',rollnumber="+txtrno.getText()+" WHERE assign_name='"+txtaname.getText()+"' ";
					
					 int i=statement.executeUpdate(query);
					
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadaname();
					
					
					
				}
				catch(SQLException updateException){
					
					displaySQLErrors(updateException);
				}
				
				 }
			
			
				 	});
			}
			});
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Assignments view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.blue) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Assignment details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("assign_name");
						       
						       model.addColumn("points");
					
						      
						       model.addColumn("feedback");
						       model.addColumn("rollnumber");
						      
						       try {
									
									rs=statement.executeQuery("select * from assignments");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("assign_name"),rs.getString("points"),rs.getString("feedback"),rs.getString("rollnumber")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
}
