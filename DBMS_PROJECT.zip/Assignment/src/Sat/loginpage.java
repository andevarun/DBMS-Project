package Sat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import Sat.*;
import java.sql.*;
import javax.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class loginpage extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JFrame StudentAssignmentsTracker;
	private JTextField txtuserid;
	private JPasswordField txtpwd;
	private JPanel contentPane;
	static String s;
	static String str1;
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run()
			{
				try 
				{
					loginpage window = new loginpage();
					window.StudentAssignmentsTracker.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				} 
			}
		});
	}
	public loginpage() {
		initialize();
	}
	JButton btnLogin;
	private void initialize() 
	{
		StudentAssignmentsTracker = new JFrame();
		StudentAssignmentsTracker.setTitle("Student Assignments Tracker");
		StudentAssignmentsTracker.setBounds(150, 150, 400, 300);
		StudentAssignmentsTracker.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		StudentAssignmentsTracker.getContentPane().setLayout(null);		
		JMenuBar menuBar = new JMenuBar();
		StudentAssignmentsTracker.setJMenuBar(menuBar);
		JMenu mnNewMenu = new JMenu("Login");
		mnNewMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				btnLogin.setVisible(true);
				
			}
		});
		menuBar.add(mnNewMenu);
		txtuserid = new JTextField();
		txtuserid.setBounds(198, 47, 96, 20);
		StudentAssignmentsTracker.getContentPane().add(txtuserid);
		txtuserid.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("User ID");
		lblNewLabel.setBounds(76, 50, 84, 14);
		StudentAssignmentsTracker.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(76, 88, 84, 14);
		StudentAssignmentsTracker.getContentPane().add(lblNewLabel_1);
	
		btnLogin = new JButton("Login");
		//contentPane.setBackground(Color.cyan);
		btnLogin.addActionListener(new ActionListener() 
		
		{
			public void actionPerformed(ActionEvent e) {
				boolean isValidUser=false;
				try 
				{
					DBconnection connect = new DBconnection();
					Connection con = connect.getConnection();
					Statement stmt=con.createStatement();
					str1=txtuserid.getText();
					String txt = "select usercategory from login where user_id = '"+txtuserid.getText()+"' and password ='"+new String(txtpwd.getPassword())+"'";
					ResultSet rs=stmt.executeQuery(txt);
					if(rs.next()) 
					{
						s=rs.getString("usercategory");
						isValidUser = true;
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				if(isValidUser) {
					UserInterface h=new UserInterface();
			
				}
				else 
				{
					JOptionPane.showMessageDialog(null,"INVALID LOGIN");
					
				}
				
			}
		});
		btnLogin.setBounds(150, 160, 89, 23);
		StudentAssignmentsTracker.getContentPane().add(btnLogin);
		txtpwd = new JPasswordField();
		txtpwd.setBounds(198, 85, 96, 20);
		StudentAssignmentsTracker.getContentPane().add(txtpwd);
	}
}

