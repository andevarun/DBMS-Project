package Sat;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class manages{
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblsection,lblstaff_id,lblaname,lblsub;
	private JTextField txtsection,txtstaff_id,txtaname,txtsub;
	private List staff_idList;
	Connection con;
	ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public manages(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{	
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lblsection=new JLabel("Section");
		lblstaff_id=new JLabel("Staff ID");
		lblsub=new JLabel("Subject");
		lblaname=new JLabel("Assignment Name");
		txtsection=new JTextField(50);
		txtstaff_id=new JTextField(50);
		txtsub=new JTextField(50);
		txtaname=new JTextField(50);
		this.p=p;	
	}
	public void connectToDB() 
    {
		try {
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737121","vasavi");  
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadstaff_id() {
		try {
			staff_idList.removeAll();
			rs=statement.executeQuery("select staff_id from manages");
			while(rs.next()) {
				staff_idList.add(rs.getString("staff_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		insertButton=new JButton("Submit");
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				txtsection.setText(null);
				txtstaff_id.setText(null);
				txtsub.setText(null);
				txtaname.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblsection);
				 p1.add(txtsection);
				 p1.add(lblstaff_id);
				 p1.add(txtstaff_id);
				 p1.add(lblsub);
				 p1.add(txtsub);
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 staff_idList=new List(10);
					 loadstaff_id();
					 p2.add(staff_idList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
			
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				   insertButton.addActionListener(new ActionListener() {
					 
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO MANAGES VALUES('"+txtsection.getText()+"',"+txtstaff_id.getText()+",'"+txtaname.getText()+"','"+txtsub.getText()+"')";
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nInserted "+i+" rows succesfully");
					loadstaff_id();
					System.out.println("Done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtsection.setText(null);
				txtstaff_id.setText(null); 
				txtsub.setText(null);
				txtaname.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();				
				p1=new JPanel();
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblsection);
				 p1.add(txtsection);
				 p1.add(lblstaff_id);
				 p1.add(txtstaff_id);
				 p1.add(lblsub);
				 p1.add(txtsub);
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					 staff_idList=new List(10);
					 loadstaff_id();
					 p2.add(staff_idList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				  staff_idList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from manages");
								while (rs.next()) 
								{
									if (rs.getString("staff_id").equals(staff_idList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtaname.setText(rs.getString("section"));
									txtstaff_id.setText(rs.getString("staff_id")); 
									txtsection.setText(rs.getString("assign_name")); 
									txtsub.setText(rs.getString("subject"));
								
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM MANAGES WHERE staff_id="+staff_idList.getSelectedItem();
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadstaff_id();
					}	
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				txtsection.setText(null);
				txtstaff_id.setText(null); 
				txtsub.setText(null);
				txtaname.setText(null);  
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblsection);
				 p1.add(txtsection);
				 p1.add(lblstaff_id);
				 p1.add(txtstaff_id);
				 p1.add(lblsub);
				 p1.add(txtsub);
				 p1.add(lblaname);
				 p1.add(txtaname);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.blue);
				 p3.setBounds(200,280,75,35);
				 p1.setBackground(Color.orange) ;
				 
				 p1.setBounds(115,80,300,200);
				
				 p2 = new JPanel(new FlowLayout());
					// p2.add(txtf1);
					 staff_idList=new List(10);
					 loadstaff_id();
					 p2.add(staff_idList);
					 p2.setBackground(Color.cyan) ;
					 p2.setBounds(125,320,300,180);  
				 
				 
				 p.add(p1);
				 p.add(p3);
				 p.add(p2);
				 
					
				    staff_idList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from manages");
								while (rs.next()) 
								{
									if (rs.getString("staff_id").equals(staff_idList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtsection.setText(rs.getString("section"));
									txtstaff_id.setText(rs.getString("staff_id")); 
									txtaname.setText(rs.getString("assign_name")); 
									txtsub.setText(rs.getString("subject"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				    p.setLayout(new BorderLayout());
					
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					loadstaff_id();
					 String query="update manages set section='"+txtsection.getText()+"',assign_name='"+txtaname.getText()+"',subject='"+txtsub.getText()+"' WHERE staff_id="+txtstaff_id.getText()+" ";
					
					 int i=statement.executeUpdate(query);
					
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadstaff_id();
					
				}
				catch(SQLException updateException){
					
					displaySQLErrors(updateException);
				}
				
				 }
			
			
				 	});
			}
			});
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Manages view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.blue) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Assignments"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						      
						       
						       model.addColumn("section");
						       model.addColumn("staff_id");
						       model.addColumn("assign_name");
						      model.addColumn("subject");
						       try {
									
									rs=statement.executeQuery("select * from manages");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("section"),rs.getString("staff_id"),rs.getString("assign_name"),rs.getString("subject")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
}
