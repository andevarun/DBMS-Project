package Sat;
import java.sql.*;
public class DBconnection 
{
	public Connection getConnection()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737121","vasavi");  
			return con;
			}
			catch (Exception connectException) 
			{
			  System.out.println(connectException);
			 
			}
		return null;
	}

}
