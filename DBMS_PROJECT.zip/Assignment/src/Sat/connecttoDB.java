package Sat;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import Sat.*;
import java.sql.*;
import javax.sql.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class connecttoDB {
	Connection con;
	ResultSet rs;
	Statement s;
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
}
}